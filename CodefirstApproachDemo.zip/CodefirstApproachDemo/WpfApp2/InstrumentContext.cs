﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;

namespace WpfApp2
{
    class InstrumentContext : DbContext
    {
        public DbSet<Instrument_172426> Instruments { get; set; }
    }
}
