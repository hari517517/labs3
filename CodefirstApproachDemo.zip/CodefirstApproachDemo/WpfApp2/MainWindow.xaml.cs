﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;


namespace WpfApp2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            InstrumentContext context = new InstrumentContext();

            context.Instruments.Add(new Instrument_172426() { ID = 100, Name = "Anuja", price = 8000, Quantity = 2 });
            context.Instruments.Add(new Instrument_172426() { ID = 101, Name = "Bhavya", price = 4000, Quantity = 3 });
            context.Instruments.Add(new Instrument_172426() { ID = 102, Name = "Anu", price = 6000, Quantity = 1 });
            
            context.SaveChanges();
            dgInstrument.ItemsSource = context.Instruments.ToList();
            var query = from ins in context.Instruments
                        where ins.price > 5000
                        select ins;

            context.Instruments.Where(ins => ins.price > 5000);
        }
    }
}
