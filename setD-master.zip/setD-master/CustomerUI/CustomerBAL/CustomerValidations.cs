﻿using CustomerDAL;
using CustomerEntities;
using CustomerException;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomerBAL
{
    public class CustomerValidations
    {
        private bool ValidateCustomer(Customer newCustomer)
        {
            bool isValidCustomer = true;
            StringBuilder sbClientError = new StringBuilder();
            if (newCustomer.CustomerName.Equals(string.Empty))//validation for blank name
            {
                isValidCustomer = false;
                sbClientError.Append("Who the hell has name blank!!:)" + Environment.NewLine);
            }
            //validation for blank city name
            if (newCustomer.City.Equals(string.Empty))
            {
                isValidCustomer = false;
                sbClientError.Append("City is  blank!!:)" + Environment.NewLine);
            }
            //validation for blank country
            if (newCustomer.Country.Equals(string.Empty))
            {
                isValidCustomer = false;
                sbClientError.Append("Country is  blank!!:)" + Environment.NewLine);
            }
            if (!isValidCustomer)
            {
                throw new Cust_Exception(sbClientError.ToString());
            }
            return isValidCustomer;
        }
        public DataTable DisplayCustomer_BLL()
        {
            try
            {
                CustomerOperations co = new CustomerOperations();
                return co.DisplayCustomer_DAL();//using display mehtod from DAL
            }
            catch (Cust_Exception c)//catching custom exception
            {
                throw c;
            }
            catch (SqlException se)//catching sql exception
            {
                throw se;
            }
            catch (Exception e)
            {
                throw e;
            }
        }
        public int AddCustomer_BLL(Customer seobj)
        {
            int cid = 0;
            try
            {
                CustomerOperations co = new CustomerOperations();
                if (ValidateCustomer(seobj))
                {
                    cid = co.AddCustomer_DAL(seobj);//using add method from DAl
                }
                else throw new Cust_Exception("Failed to Add Customer");
                return cid;
            }
            catch (Cust_Exception c)
            {
                throw c;
            }
            catch (SqlException pe)
            {
                throw pe;
            }
            catch (Exception pe)
            {
                throw pe;
            }
        }
    }
}
