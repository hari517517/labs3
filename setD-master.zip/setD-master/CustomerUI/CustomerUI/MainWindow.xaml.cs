﻿using CustomerBAL;
using CustomerEntities;
using CustomerException;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CustomerUI
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
   
        public partial class MainWindow : Window
        {

            string connStr = ConfigurationManager.ConnectionStrings["ConStr"].ToString();
            SqlConnection conObj = new SqlConnection();
            SqlCommand cmdObj;
            DataTable dtStudent = new DataTable();
            public MainWindow()
            {
                InitializeComponent();
            }

            //Displaying Auto incremented ID using Window Loaded event
            private void Window_Loaded(object sender, RoutedEventArgs e)
            {
                conObj.ConnectionString = connStr;
                //executing cmd for auto incremented ID
                cmdObj = new SqlCommand("select ident_current('CustomerDetails_172454') + ident_incr('CustomerDetails_172454')", conObj);
                try
                {
                    conObj.Open();
                    object nxId = cmdObj.ExecuteScalar();//storing the auto incremented ID 
                    txtId.Text = nxId.ToString();//displaying it in text box

                }
                catch (SqlException ex)
                {
                    MessageBox.Show(ex.Message);
                }
                finally
                {
                    conObj.Close();
                }
            }
            //Save button click event
            private void BtnSave_Click(object sender, RoutedEventArgs e)
            {
                try
                {
                    Customer c = new Customer
                    {
                        CustomerName = txtName.Text,
                        City = cbCity.Text,
                        Country = cbCountry.Text
                    };
                    CustomerValidations cv = new CustomerValidations();
                    int cid = cv.AddCustomer_BLL(c);
                    MessageBox.Show(string.Format("New Custmer Added.\nCustomer Id: {0}", cid),
                        "Customer Information System");
                    MainWindow mainWindow = new MainWindow();//creating a object for main window
                    mainWindow.Show();//showing the new Main Window so we can add next customer and the previous customer details cannot be seen
                    Close();//closing the present window
                }
                catch (Cust_Exception ex)
                {
                    MessageBox.Show(ex.Message, "Customer Information System");
                }
                catch (SqlException ex)
                {
                    MessageBox.Show(ex.Message, "Customer Information System");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Customer Information System");
                }
            }
            //Display button Click event
            private void BtnDisplay_Click(object sender, RoutedEventArgs e)
            {
                Display newWindow = new Display();
                newWindow.Show();//This will take the control to Display Window
            }
        }
    }

