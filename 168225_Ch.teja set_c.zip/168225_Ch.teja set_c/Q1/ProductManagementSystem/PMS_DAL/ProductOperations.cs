﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PMS_Entity;
using PMS_Exception;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace PMS_DAL
{
    /// <summary>
    ///  Author : Teja
    /// DoC: 04 FEB 2019
    /// Desc: To implement CRUD operation 
    /// </summary>
    public class ProductOperations
    {

        static string conStr = string.Empty;
        SqlConnection con = null;
        SqlCommand cmd = null;
        static ProductOperations()
        {
            conStr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
        }
        public ProductOperations()
        {
            con = new SqlConnection(conStr);
        }

        //adding the product in to database

        public int AddProduct(Product pboj)
        {
            int pid = 0;
            try
            {
            
                cmd = new SqlCommand();
                cmd.CommandText = "cteja1_168225.uspAddProduct";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add("@pId", SqlDbType.Int);
                cmd.Parameters["@pId"].Direction = ParameterDirection.Output;

                cmd.Parameters.AddWithValue("@pName", pboj.ProductName);
                cmd.Parameters.AddWithValue("@descp", pboj.Description);
                cmd.Parameters.AddWithValue("@p", pboj.Price);
   

                con.Open();
                int noOfRowsAffected = cmd.ExecuteNonQuery();
                pid = int.Parse(cmd.Parameters["@pId"].Value.ToString());
            }

            catch (SqlException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return pid;
        }

        // taking the data from database

        public DataTable Display()
        {
            DataTable dt = null;

            try
            {
              
                cmd = new SqlCommand();
                cmd.CommandText = "cteja1_168225.uspGetProducts";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dt = new DataTable();
                    dt.Load(dr);
                }
            }
            catch (SqlException)
            { throw; }
            catch (Exception)
            { throw; }
            finally
            {

                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return dt;
        }
    }
}
