﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PMS_Exception
{
    public class ProductException : Exception

    {
        public ProductException(string errormessage) : base(errormessage)
        {

        }

    }
}
