﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PMS_DAL;
using PMS_Entity;
using PMS_Exception;
using System.Data.SqlClient;
using System.Data;
using System.Text.RegularExpressions;
namespace PMS_BAL
{
    public class ProductValidations
    {
        // checking the given data is correct Or not

        private bool ValidateProduct(Product newProduct)
        {
            bool isValidProduct = true;

            
            StringBuilder sbEMSError = new StringBuilder();

            if (newProduct.Description.ToString().Equals(string.Empty))
            {
                isValidProduct = false;
                sbEMSError.Append("Product Description cannot be blank " + Environment.NewLine);

            }


            if (newProduct.ProductName.ToString().Equals(string.Empty))
            {
                isValidProduct = false;
                sbEMSError.Append("Product Name cannot be blank " + Environment.NewLine);

            }
            if (newProduct.Price.ToString().Equals(string.Empty))
            {
                isValidProduct = false;
                sbEMSError.Append("Product Price cannot be blank " + Environment.NewLine);

            }
        


            return isValidProduct;
        }

        // checking and adding the product

        public int AddProduct(Product pobj)
        {
            int prodId = 0;
            try
            {
                ProductOperations pd = new ProductOperations();
                if (ValidateProduct(pobj))
                {
                    prodId = pd.AddProduct(pobj);
                }
                else throw new ProductException("Failed to Add Product");
                return prodId;
            }
            catch (ProductException pe)
            {
                throw pe;
            }
            catch (SqlException pe)
            {
                throw pe;
            }
            catch (Exception pe)
            {
                throw pe;
            }
        }

        // checking given data and sending to datable

        public DataTable Display()
        {
            try
            {
                ProductOperations pd = new ProductOperations();
                DataTable dtProduct = pd.Display();
                if (dtProduct.Rows.Count <= 0)
                {
                    throw new ProductException("No Products Available");
                }
                return dtProduct;
            }
            catch (ProductException pe)
            { throw pe; }
            catch (SqlException se)
            { throw se; }
            catch (Exception e)
            { throw e; }
        }
    }
}
