﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using PMS_Entity;
using PMS_Exception;
using PMS_BAL;

namespace ProductDetails_UI
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        string connStr = ConfigurationManager.ConnectionStrings["ConStr"].ToString();
        SqlConnection conObj = new SqlConnection();
        SqlCommand cmdObj;
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Btn_add_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Product p = new Product
                {
                    ProductName = txtPName.Text,
                    Description = txtDescp.Text,
                    Price = decimal.Parse(txtP.Text),
                   
                };
                ProductValidations pb = new ProductValidations();
                int pid = pb.AddProduct(p);
                MessageBox.Show(string.Format("New Product Added.\nProduct Id: {0}", pid),
                    "Product Management System");
            }
            catch (ProductException ex)
            {
                MessageBox.Show(ex.Message, "Product Management System");
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, "Product Management System");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Product Management System");
            }
        
    }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            conObj.ConnectionString = connStr;
            cmdObj = new SqlCommand("select ident_current('cteja1_168225.Product') + ident_incr('cteja1_168225.Product')", conObj);
            try
            {
                conObj.Open();
                object nxId = cmdObj.ExecuteScalar();
                
                txt_Id.Text = nxId.ToString();

            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conObj.Close();
            }


        }

        private void Btn_Displays_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                ProductValidations st = new ProductValidations();
                DataTable dt = st.Display();
                dg_display.ItemsSource = dt.DefaultView;


            }
            catch (ProductException ex)
            {
                MessageBox.Show(ex.Message, "employee Management System");
            }
            catch (SqlException se)
            {

                MessageBox.Show(se.Message.ToString());
            }
            finally
            {

            }

        }

        private void Dg_display_Scroll(object sender, System.Windows.Controls.Primitives.ScrollEventArgs e)
        {

        }
    }
}
