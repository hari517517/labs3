create schema cteja1_168225
create table cteja1_168225.Product
(
ProductId int identity(1,1) primary key,
ProductName varchar(25) unique not null,
Description varchar(250) null,
Price numeric not null

)
drop table  cteja1_168225.Product
insert into cteja1_168225.Product
values ( ('Grandmas pickle'),('12 - 8 oZ jars'),62500)
insert into cteja1_168225.Product
values ( ('Chai '),('10boxes * 20bags'),62500)

insert into cteja1_168225.Product
values ( ('changs '),('24-12 oZ bottles'),47500)

insert into cteja1_168225.Product
values ( ('Aniseed Syrup'),('12 -550ml '),25000)

insert into cteja1_168225.Product
values ( ('Chef antons caju'),('48 - 6 jars'),55000)
insert into cteja1_168225.Product
values ( ('chef antons gulab'),('36 boxes'),53375)



select * from  cteja1_168225.Product

-------- Stored Procedure for adding New product--------------------
go

alter proc cteja1_168225.uspAddProduct
(
@pName varchar(25),
@descp varchar(250),
@p numeric,

@pId int output
)
as
begin
	insert into cteja1_168225.Product
	values(@pName,@descp,@p)
	set @pId = Scope_Identity()
end
----------------Display products--------------
go

create proc cteja1_168225.uspGetProducts
as
begin
	select * from  cteja1_168225.Product
end
