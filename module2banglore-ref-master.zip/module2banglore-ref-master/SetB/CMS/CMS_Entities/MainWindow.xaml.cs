﻿using CMS_BAL;
using CMS_Exceptions;
using Customer_UI;
using CustomerMS_Entities;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Customer_Management_System
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
      

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            CustomerBAL eb = new CustomerBAL();
            txt_custid.Text = eb.Auto().ToString();
        }

        private void save_Click_1(object sender, RoutedEventArgs e)
        {
            try
            {
                Customer cust = new Customer();

                cust.Cust_Name = txt_Name.Text;
                cust.Cust_City = cb_City.Text;
                cust.Cust_Country = cb_country.Text;
                CustomerBAL bal = new CustomerBAL();
                bal.Add(cust);
                MessageBox.Show("Information is added in Database");
                txt_Name.Clear();
                cb_City.SelectedItem = null;
                cb_country.SelectedItem = null;

            }
            catch (CustomerException ex1)
            {
                MessageBox.Show(ex1.Message);

            }
            catch (SqlException ex2)
            {

                MessageBox.Show(ex2.Message);
            }
            catch (Exception ex3)
            {


                MessageBox.Show(ex3.Message);
            }
        }

        private void Display_Click_1(object sender, RoutedEventArgs e)
        {
            Display Dis = new Display();
            Dis.Show();
        }
    }
}
