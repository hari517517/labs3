﻿using CMS_DAL;
using CMS_Exceptions;
using CustomerMS_Entities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace CMS_BAL
{
    public class CustomerBAL
    {
        private bool IsValid(Customer cust)
        {

            bool valid = true;
            StringBuilder sb = new StringBuilder();

            if (!(Regex.IsMatch(cust.Cust_Name, @"^[A-Z,a-z]+$")))
            {
                valid = false;
                sb.Append(Environment.NewLine + "Name should not number and special charecters ");
            }
            if (cust.Cust_City == string.Empty)
            {
                valid = false;
                sb.Append(Environment.NewLine + "Customer City should not empty");
            }
            if (cust.Cust_Country == string.Empty)
            {
                valid = false;
                sb.Append(Environment.NewLine + "Customer country should not empty");
            }

            if (!valid)
            {
                throw new CustomerException(sb.ToString());
            }

            return valid;
        }


        CustomerDAL dAL = new CustomerDAL();
        public void Add(Customer cust)
        {

            try
            {

                if (IsValid(cust))
                {
                    dAL.AddCustomer(cust);
                }

            }
            catch (CustomerException ex1)
            {
                throw ex1;

            }
            catch (SqlException ex2)
            {
                throw ex2;
            }
            catch (Exception ex3)
            {

                throw ex3;
            }

        }


        public DataTable Display()
        {
            try
            {
                return dAL.Display();

            }
            catch (CustomerException ex) { throw ex; }
            catch (SqlException ex1)
            {
                throw ex1;
            }
            catch (SystemException ex2)
            {
                throw ex2;
            }

        }

        public int Auto()
        {
            CustomerDAL dal = new CustomerDAL();
            return dal.AutoMat();
        }

    }

}

