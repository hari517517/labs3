﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomerMS_Entities
{
    public class Customer
    {
        public int Cust_Id { get; set; }
        public string Cust_Name { get; set; }
        public string Cust_City { get; set; }
        public string Cust_Country { get; set; }
    }
}
