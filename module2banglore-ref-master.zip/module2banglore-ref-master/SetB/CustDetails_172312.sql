create table CustDetails_172312
(
CustomerID  INT identity(100,1) ,
CustomerName varchar(50) not null,
City varchar(50),
Country varchar(50)
)

insert into CustDetails_172312 values ('fari','mum','India');
insert into CustDetails_172312 values ('raji','chn','India');
insert into CustDetails_172312 values ('fari','ban','India');
insert into CustDetails_172312 values ('fari','del','India');

select*from CustDetails_172312
alter table CustDetails_172312

add constraint customerpk primary key (CustomerID)