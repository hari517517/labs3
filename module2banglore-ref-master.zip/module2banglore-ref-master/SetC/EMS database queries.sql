









create table MARKETProduct_172312
(
  ProductId int  identity (1,1) primary key,
  ProductName varchar(50),
  Descript varchar(1000),
  Price int, 
);

select * from MARKETProduct_172312

INSERt Into MARKETProduct_172312 VALUES('COLGATE','PASTE',45)









CREATE PROCEDURE DisplayProduct_172312
	
AS
begin
	SELECT * from MARKETProduct_172312
END







CREATE PROCEDURE SP_ADD_Product_172312
	(
	@ProductName varchar(50),
	@Descript varchar(1000),
	@Price int,
	@ProductId int output)
AS
	insert into MARKETProduct_172312
	values (@ProductName, @Descript,@Price)
	set @ProductId=SCOPE_IDENTITY()
return 0
exec SP_ADD_Product_172312 
	


