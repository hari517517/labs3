﻿using EMSEntity;
using EMSException;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMSDAL
{
    public class ProductDAL
    {
        static string conStr = string.Empty;
        SqlConnection con = null;
        SqlCommand cmd = null;
        static ProductDAL()
        {
            conStr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
        }
        public ProductDAL()
        {
            con = new SqlConnection(conStr);
        }
        public DataTable DisplayProductDal()
        {
            DataTable dt = null;


            try
            {

                // con = new SqlConnection();
                //con.ConnectionString = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
                cmd = new SqlCommand();
                cmd.CommandText = "DisplayProduct_172312";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;

                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dt = new DataTable();
                    dt.Load(dr);
                }
            }

            catch (SqlException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return dt;
        }
        public int AddProductDal(ProductEntity pboj)
        {
            int pid = 0;
            try
            {
                //con = new SqlConnection();
                //con.ConnectionString = conStr; 
                cmd = new SqlCommand();
                cmd.CommandText = "SP_ADD_Product_172312";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add("@ProductId", SqlDbType.Int);
                cmd.Parameters["@ProductId"].Direction = ParameterDirection.Output;

                cmd.Parameters.AddWithValue("@ProductName", pboj.ProductName);
                cmd.Parameters.AddWithValue("@Descript", pboj.Description);
                cmd.Parameters.AddWithValue("@Price", pboj.UnitPrice);


                con.Open();
                int noOfRowsAffected = cmd.ExecuteNonQuery();
                pid = int.Parse(cmd.Parameters["@ProductId"].Value.ToString());
            }
            catch (ProductException)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return pid;
        }
    }
}

