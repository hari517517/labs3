﻿using PMS_BAL;
using PMS_Entity1;
using PMS_Exception;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PMS_UI
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class PatientRegistrationForm : Window
    {

        string connStr = ConfigurationManager.ConnectionStrings["ConStr"].ToString();
        SqlConnection conObj = new SqlConnection();
        SqlCommand cmdObj;



        public PatientRegistrationForm()
        {
            InitializeComponent();
        }



        //window loaded for loading Date & Patient ID

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {

            conObj.ConnectionString = connStr;
            cmdObj = new SqlCommand("select ident_current('Patientdetails_172312') + ident_incr('Patientdetails_172312')", conObj);
            try
            {
                DateTime date1 = new DateTime();
                date1 = DateTime.Now;
                tb_Login.Text = date1.ToString();
                conObj.Open();
                object nxId = cmdObj.ExecuteScalar();
                //int nxtId = Convert.ToInt32(nxId);
                tb_ID.Text = nxId.ToString();

            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conObj.Close();
            }


        }

        //Adding Patient Details

        private void Btn_AddPatient_Click(object sender, RoutedEventArgs e)
        {

            try
            {


                string GE = " ";


                if (rbtn_Male.IsChecked == true)
                    GE = rbtn_Male.Content.ToString();

                else if (rbtn_Female.IsChecked == true)
                    GE = rbtn_Female.Content.ToString();

                DateTime date1 = new DateTime();
                date1 = DateTime.Now;

                Patient p = new Patient
                {
                    LoginTime = DateTime.Parse(tb_Login.Text),
                    PatientId = int.Parse(tb_ID.Text),
                    FistName = txt_FirstName.Text,
                    LastName = txt_LastName.Text,
                    Gender = char.Parse(GE),//convert.ToString(GE)//
                    Address = txt_Address.Text,
                    City = txt_City.Text,
                    State = txt_State.Text,
                    PinCode = txt_PinCode.Text,
                    PhoneNumber = long.Parse(txt_Phone.Text)


                };
                PatientBAL pb = new PatientBAL();
                pb.AddPatientBAL(p);
                MessageBox.Show(string.Format("New Patient Added", "Patient Management System"));
            }
            catch (PatientException ex)
            {
                MessageBox.Show(ex.Message, "Patient Management System");
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message, "Patient Management System");
            }


        }


    }
}
