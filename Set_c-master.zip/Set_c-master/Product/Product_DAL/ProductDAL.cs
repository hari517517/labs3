﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;//rayali connection
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Product_Entity;
using Product_Exception;
using System.Data;//command
using System.Configuration;//Configuration manager, reference kuda evvali


namespace Product_DAL
{
    public class ProductDAL
    {

        static string conStr = string.Empty;
        SqlConnection con = null;
        SqlCommand cmd = null;
        static ProductDAL()
        {
            conStr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
        }
        public ProductDAL()
        {
            con = new SqlConnection(conStr);
        }
        public DataTable DisplayProductDal()
        {
            DataTable dt = null;


            try
            {

                // con = new SqlConnection();
                //con.ConnectionString = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
                cmd = new SqlCommand();
                cmd.CommandText = "Displayproduct_172308_Praveena";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;

                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dt = new DataTable();
                    dt.Load(dr);
                }
            }

            catch (SqlException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return dt;
        }
        public int AddProductDal(Entity pboj)
        {
            int pid = 0;
            try
            {
                //con = new SqlConnection();
                //con.ConnectionString = conStr; 
                cmd = new SqlCommand();
                cmd.CommandText = "Insertproduct_172308_Praveena";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add("@pId", SqlDbType.Int);
                cmd.Parameters["@pId"].Direction = ParameterDirection.Output;

                cmd.Parameters.AddWithValue("@productName", pboj.ProductName);
                cmd.Parameters.AddWithValue("@descript", pboj.Description);
                cmd.Parameters.AddWithValue("@unitPrice", pboj.UnitPrice);


                con.Open();
                int noOfRowsAffected = cmd.ExecuteNonQuery();
                pid = int.Parse(cmd.Parameters["@pId"].Value.ToString());
            }
            catch (ProductException) { throw; }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return pid;
        }

    }
}
